import edu.princeton.cs.algs4.BinaryIn;
import edu.princeton.cs.algs4.BinaryOut;

import java.util.Objects;

public class MoveToFront {

    private final static int R = 256;
    private char[] sequence;

    public MoveToFront() {
        sequence = new char[R];
        for (char i = 0; i < R; i++) sequence[i] = i;
    }

    private char moveChar(char c) {
        for (char i = 0; i < R; i++) {
            if (sequence[i] == c) {
                move(c, i);
                return i;
            }
        }

        throw new IllegalStateException("Character " + c + " is not in the sequence");
    }

    private void move(char c, char i) {
        for (char j = i; j > 0; j--) {
            sequence[j] = sequence[j-1];
        }
        sequence[0] = c;
    }

    private char moveIndex(char i) {
        char c = sequence[i];
        move(c, i);
        return c;
    }

    // apply move-to-front encoding, reading from standard input and writing to standard output
    public static void encode() {
        MoveToFront codec = new MoveToFront();
        BinaryIn in = new BinaryIn();
        BinaryOut out = new BinaryOut();
        while (!in.isEmpty()) {
            out.write(codec.moveChar(in.readChar()));
        }
        out.close();
    }

    // apply move-to-front decoding, reading from standard input and writing to standard output
    public static void decode() {
        MoveToFront codec = new MoveToFront();
        BinaryIn in = new BinaryIn();
        BinaryOut out = new BinaryOut();
        while (!in.isEmpty()) {
            out.write(codec.moveIndex(in.readChar()));
        }
        out.close();
    }

    // if args[0] is '-', apply move-to-front encoding
    // if args[0] is '+', apply move-to-front decoding
    public static void main(String[] args) {
        if (Objects.equals(args[0], "-")) encode();
        else if (Objects.equals(args[0], "+")) decode();
        else throw new IllegalArgumentException("args[0] must be '-' for encoding or '+' for decoding");
    }
}
