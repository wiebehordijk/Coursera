import edu.princeton.cs.algs4.BinaryIn;
import edu.princeton.cs.algs4.BinaryOut;

public class BurrowsWheeler {

    // apply Burrows-Wheeler transform, reading from standard input and writing to standard output
    public static void transform() {
        BinaryIn in = new BinaryIn();
        String input = in.readString();
        CircularSuffixArray suffix = new CircularSuffixArray(input);

        // Output index where original string ends up in the sorted circular suffix array, and
        // Output last column of sorted circular suffix array
        StringBuilder builder = new StringBuilder();
        int indexZero = -1;
        for (int i = 0; i < suffix.length(); i++) {
            if (suffix.index(i) == 0) {
                indexZero = i;
                builder.append(input.charAt(suffix.length() - 1));
            }
            else {
                builder.append(input.charAt(suffix.index(i) - 1));
            }
        }

        BinaryOut out = new BinaryOut();
        out.write(indexZero);
        out.write(builder.toString());
        out.close();
    }

    // apply Burrows-Wheeler inverse transform, reading from standard input and writing to standard output
    public static void inverseTransform() {
        BinaryIn in = new BinaryIn();
        int first = in.readInt();
        String input = in.readString();
        int length = input.length();

        // CountSort
        final int R = 256;
        int[] count = new int[R+1];
        for (int i = 0; i < length; i++) {
            count[input.charAt(i)+1]++;
        }
        for (int i = 1; i <= R; i++) {
            count[i] += count[i-1];
        }
        char[] sorted = new char[length];
        int[] next = new int[length];
        for (int i = 0; i < length; i++) {
            char c = input.charAt(i);
            int index = count[c]++;
            sorted[index] = c;
            next[index] = i;
        }

        // Get original string from sorted (first) column and next array
        int index = first;
        BinaryOut out = new BinaryOut();
        for (int i = 0; i < length; i++) {
            out.write(sorted[index]);
            index = next[index];
        }
        out.close();
    }

    // if args[0] is '-', apply Burrows-Wheeler transform
    // if args[0] is '+', apply Burrows-Wheeler inverse transform
    public static void main(String[] args) {
        if (args[0].equals("-"))
            transform();
        else if (args[0].equals("+"))
            inverseTransform();
        else
            throw new IllegalArgumentException("args[0] must be - for transform or + for inverse transform");
    }

}
